<?php
session_start();
session_destroy(); // Destroy the session to log out the user

// Redirect to login page
header("Location: ../html/main.php");
exit();
?>
