<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car_registration";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // User details
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if the username exists
    $stmt = $conn->prepare("SELECT password, profile_picture FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Fetch the hashed password
        $stmt->bind_result($hashed_password, $profile_picture);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashed_password)) {
            // Successful login
            session_start();
            $_SESSION['username'] = $username;
            $_SESSION['profile_picture'] = $profile_picture;

            // Redirect to car registration page
            header("Location: index.php");
            exit();
        } else {
            // Invalid password
            echo "<script>alert('Incorrect password. Please try again.');</script>";
            echo "<script>window.location.href = '../html/login.html';</script>";
        }
    } else {
        // Username does not exist
        echo "<script>alert('Invalid username. Please register or try again.');</script>";
        echo "<script>window.location.href = '../html/login.html';</script>";
    }

    $stmt->close();
}
$conn->close();
?>
