<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car_registration";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $carId = $_GET['id'];

    // Prepare and execute the delete query
    $sql = "DELETE FROM cars WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $carId);

    if ($stmt->execute()) {
        // Redirect back to the main page after deletion
        header("Location: index.php");
        exit;
    } else {
        echo "Error deleting car: " . $conn->error;
    }
    $stmt->close();
}
$conn->close();
?>
